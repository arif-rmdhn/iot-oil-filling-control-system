/* Define a shared variable named 'counter' of type 'int'. */
SHARED(counter, int);
